<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require 'kint.phar';

if (! function_exists('digits')) {

    function digits_set($data)
    {
        // get main CodeIgniter object
        $ci = get_instance();
       
        // Write your logic as per requirement
        return sprintf("%'.04d", $data);
    }

    function date_set($data){
    	 // get main CodeIgniter object
       
        $CI = get_instance();
        $CI->load->library('session');
       
        // Write your logic as per requirement
        return date($CI->session->userdata('date_setting_format')->date_format, strtotime($data));
    	
    }

    function viewme($data)
    {
       // return echo "<pre>". htmlspecialchars(print_r($data, true)). "</pre>";
    }

    function num_format_set($number){

        $CI = get_instance();
        $CI->load->library('session');

        $condion_check = $CI->session->userdata('date_setting_format')->number_format;
        
            // if($condion_check == 'india_format'){
            //     setlocale(LC_MONETARY, 'en_IN');
            //     return money_format('%!i', sprintf('%0.2f', $number));
            // }elseif ($condion_check == 'dollar_format') {
            //     setlocale(LC_MONETARY, 'en_US');
            //     return money_format('%!i', sprintf('%0.2f', $number));
            // }elseif ($condion_check == 'normal_format') {
                return $number;
            // }

    }


    function digits_to_string($number)
    {
        // $number = $credit_note[0]['Approval_amount'];
        $no = round($number);
        $point = round($number - $no, 2) * 100;
        $hundred = null;
        $digits_1 = strlen($no);
        $i = 0;
        $str = array();
        $words = array('0' => '', '1' => 'one', '2' => 'two',
        '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
        '7' => 'seven', '8' => 'eight', '9' => 'nine',
        '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
        '13' => 'thirteen', '14' => 'fourteen',
        '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
        '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
        '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
        '60' => 'sixty', '70' => 'seventy',
        '80' => 'eighty', '90' => 'ninety');
        $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
        while ($i < $digits_1) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += ($divider == 10) ? 1 : 2;
        if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
        " " . $digits[$counter] . $plural . " " . $hundred
        :
        $words[floor($number / 10) * 10]
        . " " . $words[$number % 10] . " "
        . $digits[$counter] . $plural . " " . $hundred;
        } else $str[] = null;
        }
        $str = array_reverse($str);

        $result = implode('', $str);
        // $points = ($point) ?
        // "." . $words[$point / 10] . " " . 
        // $words[$point = $point % 10] : '';
        return  $result . "rupees  " ;//. $points . " Paise"
    }

    function object_to_array($get_data)
    {
        $array = [];
        foreach ($get_data as $value){
          $data = (array) $value;
          array_push($array, (array) $value);
        }
        return $array;
    }

    function check_for_region_based_logo($region_id)
    {
        $region_ids = ['16','4'];
        if (in_array($region_id, $region_ids))
          {
            return 1;
          }
        else
          {
            return 0;
          }
    }
    /*
        $this->session->userdata('company_logo')
        
            if(check_for_region_based_logo($grn_details[0]->Region_id) == 0){
                $image_url = base_url().'attachments/company_logo/'.$grn_details[0]->company_logo;  
            }else{
                $image_url = '';
            }   
    */

}