<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends CI_Model {

	public function FunctionName($value='')
	{
		# code...
	}

}

/* End of file common_model.php */
/* Location: ./application/models/common_model.php */