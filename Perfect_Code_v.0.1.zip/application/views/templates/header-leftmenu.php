<!-- <li class="<?php if($this->uri->uri_string()=='master/company/prefix_setting'){echo 'active';}?>">
	<a href="<?php echo base_url(); ?>master/company/prefix_setting"><i class="zmdi zmdi-caret-right zmdi-hc-fw"></i>
		Prefix Setting
	</a>
</li> -->

<br />

IM HEADER LEFT

<br />