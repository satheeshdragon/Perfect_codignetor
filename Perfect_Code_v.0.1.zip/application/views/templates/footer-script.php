<script src="<?php echo base_url(); ?>assets/vendor/modernizr/modernizr.custom.js"></script>

<br />

FOOTER SCRIPT

<br />
